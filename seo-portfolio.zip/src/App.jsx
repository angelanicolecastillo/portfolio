
import React from 'react'
import SEOPortfolio from './SEOPortfolio'
import './index.css'

function App() {
  return <SEOPortfolio />
}

export default App
